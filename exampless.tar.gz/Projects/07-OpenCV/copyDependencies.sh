#!/bin/bash

mvn dependency:copy-dependencies
