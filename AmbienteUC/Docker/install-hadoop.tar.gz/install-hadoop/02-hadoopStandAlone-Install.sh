#!/bin/bash

source 01-hadoopDefs.sh

checkSoftware java
checkSoftware javac
checkSoftware mvn
checkSoftware wget
checkSoftware tar
checkSoftware ssh
checkSoftware sshpass

echo -e "\nEnsure that SSH option \"PermitUserEnvironment\" is set to yes"

showJavaEnvironment
showMavenEnvironment

showMessageWithTimeout "Press ENTER to download Hadoop tar ball"
downloadHadoopTarball

showMessageWithTimeout "Press ENTER to install Hadoop tar ball"
installHadoopTarball

showMessageWithTimeout "Press ENTER to set up Hadoop stand alone environment"
setHadoopEnvironmentStandAlone

showMessageWithTimeout "Press ENTER to show Hadoop version"
showHadoopVersion

showMessageWithTimeout "Press ENTER to finish stand alone installation"
