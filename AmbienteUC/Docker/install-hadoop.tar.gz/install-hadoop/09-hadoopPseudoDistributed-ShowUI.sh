#!/bin/bash

source 01-hadoopDefs.sh

echo -e "\nWeb UI is available at:"

echo -e "\nFor the HDFS service (Name node):"
echo -e "http://${DFS_NAMENODE_HTTP_NAME}:${WebUI_HTTP_NAMENODE_HDFS}/"
if [ ${SECURE_MODE} == "true" ]; then
	echo -e "https://${DFS_NAMENODE_HTTP_NAME}:${WebUI_HTTPS_NAMENODE_HDFS}/"
fi


echo -e "\nFor the HDFS service (Secondary name node):"
echo -e "http://${DFS_SECONDARYNAMENODE_HTTP_NAME}:${WebUI_HTTP_SECONDARYNAMENODE_HDFS}/"
if [ ${SECURE_MODE} == "true" ]; then
	echo -e "https://${DFS_SECONDARYNAMENODE_HTTP_NAME}:${WebUI_HTTPS_SECONDARYNAMENODE_HDFS}/"
fi

echo -e "\nFor the HDFS service (Data nodes):"
_hosts=`cat ${HADOOP_CONF_DIR}/${FILE_NODES_WORKERS}`
for _host in ${_hosts}; do
	echo -e "http://${_host}:${WebUI_HTTP_DATANODE_HDFS}/"
	if [ ${SECURE_MODE} == "true" ]; then
		echo -e "https://${_host}:${WebUI_HTTPS_DATANODE_HDFS}/"
	fi
done

echo -e "\nFor the MapReduce service:"
echo -e "http://${MR_HTTP_NAME}:${WebUI_HTTP_MR}/"
if [ ${SECURE_MODE} == "true" ]; then
	echo -e "https://${MR_HTTP_NAME}:${WebUI_HTTPS_MR}/"
fi

echo -e "\nFor the YARN service (Resource Manager):"
echo -e "http://${YARN_RM_HTTP_NAME}:${WebUI_HTTP_YARN_RM}/"
if [ ${SECURE_MODE} == "true" ]; then
	echo -e "https://${YARN_RM_HTTP_NAME}:${WebUI_HTTPS_YARN_RM}/"
fi

echo -e "\nFor the YARN service (Nodes Manager):"
_hosts=`cat ${HADOOP_CONF_DIR}/${FILE_NODES_WORKERS}`
for _host in ${_hosts}; do
	echo -e "http://${_host}:${WebUI_HTTP_YARN_NM}/"
	if [ ${SECURE_MODE} == "true" ]; then
		echo -e "https://${_host}:${WebUI_HTTPS_YARN_NN}/"
	fi
done
