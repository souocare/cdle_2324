#!/bin/bash

if [[ $# -lt 1 ]]; then
	echo -e "Invalid arguments!"
	echo -e "Usage:"
	echo -e "$0 <UserName>"
	exit
fi

UserName=$1

source 01-hadoopDefs.sh

showMessageWithTimeout "Press ENTER to add user (${UserName}) to Hadoop group (${HADOOP_GROUP})"

CMD="sudo usermod -a -G ${HADOOP_GROUP} ${UserName}"
echo -e ${CMD}
${CMD}

declare -a CommandsCreateUserDir=(
	"${HADOOP_HOME}/bin/hadoop fs -mkdir -p /user/${UserName}"
	"${HADOOP_HOME}/bin/hadoop fs -chown ${UserName}:${HADOOP_GROUP} /user/${UserName}"
)	

showMessageWithTimeout "Press ENTER to create HDFS directory for user (${UserName})"
for currentCommand in "${CommandsCreateUserDir[@]}"
do
	CMD="sshpass -p ${HADOOP_PASS_HDFS} ssh ${SSH_OPTIONS} ${HADOOP_USER_HDFS}@localhost \"\"${currentCommand}\"\""
	echo -e ${CMD}
	${CMD}
done
