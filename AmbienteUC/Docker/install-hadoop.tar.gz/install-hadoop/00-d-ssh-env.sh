#!/bin/bash

FILE=${HOME}/.ssh/environment

if [ -f "${FILE}" ]; then
    echo "${FILE} exists."
	
	cat ${FILE} | grep JAVA_HOME > /dev/null
	if [[ "$?" -eq 1 ]]; then
		echo "Setting JAVA_HOME..."
		echo "JAVA_HOME=${JAVA_HOME}" >> ${FILE}
	fi
		
	cat ${FILE} | grep MAVEN_HOME > /dev/null
	if [[ "$?" -eq 1 ]]; then
		echo "Setting MAVEN_HOME..."
		echo "MAVEN_HOME=${MAVEN_HOME}" >> ${FILE}
	fi

else 
    echo "${FILE} does not exist."
	
	echo "Setting JAVA_HOME..."
	echo "JAVA_HOME=${JAVA_HOME}" > ${FILE}
	
	echo "Setting MAVEN_HOME..."
	echo "MAVEN_HOME=${MAVEN_HOME}" >> ${FILE}
fi
