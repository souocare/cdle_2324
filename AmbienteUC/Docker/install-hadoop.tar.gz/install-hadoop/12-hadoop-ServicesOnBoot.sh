#!/bin/bash

source 01-hadoopDefs.sh

echo -e "Saving current IFS..."
CurrentIFS=${IFS}

IFS='' read -r -d '' HDFS_SYSTEMD_SERVICE_FILE_SETTINGS << EOM
[Unit]
Description=HDFS Hadoop service
After=networking

[Service]
Environment=JAVA_HOME=${JAVA_HOME}
Environment=HADOOP_HOME=${HADOOP_HOME}
Environment=HADOOP_MAPRED_HOME=${HADOOP_MAPRED_HOME}
Environment=HADOOP_CONF_DIR=${HADOOP_CONF_DIR}
Type=oneshot
RemainAfterExit=true
User=${HADOOP_USER_HDFS}
ExecStart=${HADOOP_HOME}/sbin/start-dfs.sh
ExecStop=${HADOOP_HOME}/sbin/stop-dfs.sh

[Install]
WantedBy=multi-user.target

EOM

IFS='' read -r -d '' YARN_SYSTEMD_SERVICE_FILE_SETTINGS << EOM
[Unit]
Description=HDFS Hadoop service
After=networking

[Service]
Environment=JAVA_HOME=${JAVA_HOME}
Environment=HADOOP_HOME=${HADOOP_HOME}
Environment=HADOOP_MAPRED_HOME=${HADOOP_MAPRED_HOME}
Environment=HADOOP_CONF_DIR=${HADOOP_CONF_DIR}
Type=oneshot
RemainAfterExit=true
User=${HADOOP_USER_YARN}
ExecStart=${HADOOP_HOME}/sbin/start-yarn.sh
ExecStop=${HADOOP_HOME}/sbin/stop-yarn.sh

[Install]
WantedBy=multi-user.target

EOM

IFS='' read -r -d '' MAPREDUCE_SYSTEMD_SERVICE_FILE_SETTINGS << EOM
[Unit]
Description=YARN Hadoop service
Requires=hdfs.service
After=hdfs.service

[Service]
Environment=JAVA_HOME=${JAVA_HOME}
Environment=HADOOP_HOME=${HADOOP_HOME}
Environment=HADOOP_MAPRED_HOME=${HADOOP_MAPRED_HOME}
Environment=HADOOP_CONF_DIR=${HADOOP_CONF_DIR}
Type=oneshot
RemainAfterExit=true
User=${HADOOP_USER_MR}
ExecStart=${HADOOP_HOME}/bin/mapred --daemon start historyserver
ExecStop=${HADOOP_HOME}/bin/mapred --daemon stop historyserver

[Install]
WantedBy=multi-user.target

EOM

echo -e "Restoring IFS..."
IFS=${currentIFS}

showMessageWithTimeout "Press ENTER to configure HDFS as a service at boot time"
createSystemdFile ${HDFS_SYSTEMD_SERVICE_FILE_SETTINGS} "hdfs" ${HDFS_SYSTEMD_SERVICE_FILE} ${SYSTEMD_SERVICE_DIRECTORY}

showMessageWithTimeout "Press ENTER to configure YARN as a service at boot time"
createSystemdFile ${YARN_SYSTEMD_SERVICE_FILE_SETTINGS} "yarn" ${YARN_SYSTEMD_SERVICE_FILE} ${SYSTEMD_SERVICE_DIRECTORY}

showMessageWithTimeout "Press ENTER to configure MapReduce as a service at boot time"
createSystemdFile ${MAPREDUCE_SYSTEMD_SERVICE_FILE_SETTINGS} "mapreduce" ${MAPREDUCE_SYSTEMD_SERVICE_FILE} ${SYSTEMD_SERVICE_DIRECTORY}
