#!/bin/bash

10-hadoopPseudoDistributed-Stop.sh 2>&1 | tee ~/uninstallHadoop.log

05-hadoopPseudoDistributed-Erase.sh 2>&1 | tee -a ~/uninstallHadoop.log